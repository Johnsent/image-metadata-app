
import React, { useState, useEffect } from 'react';
import { SettingsView } from './components/SettingsView';
import { MainView } from './components/MainView';
import { DEFAULT_PROMPTS } from './constants';
import type { PromptsConfig } from './types';
import { loadPromptsFromStorage, savePromptsToStorage } from './utils/localStorageHelper';
import { NavIcon, SettingsIcon } from './components/icons';

enum Page {
  Main = 'Main',
  Settings = 'Settings',
}

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Main);
  const [appConfig, setAppConfig] = useState<PromptsConfig>(DEFAULT_PROMPTS);
  
  useEffect(() => {
    const loadedConfig = loadPromptsFromStorage();
    setAppConfig(loadedConfig);
  }, []);

  const isApiKeySet = !!appConfig.apiKey;

  const handleSaveConfig = (newConfig: PromptsConfig) => {
    setAppConfig(newConfig);
    savePromptsToStorage(newConfig);
    alert('Configuration saved successfully!');
    setCurrentPage(Page.Main);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-gray-100 flex flex-col items-center p-4">
      <header className="w-full max-w-5xl mb-8 p-6 bg-slate-800 rounded-xl shadow-2xl">
        <div className="flex justify-between items-center">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500">
            AI Image Metadata Generator
          </h1>
          <nav className="flex space-x-4">
            <button
              onClick={() => setCurrentPage(Page.Main)}
              className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ease-in-out flex items-center space-x-2
                ${currentPage === Page.Main 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg' 
                  : 'bg-slate-700 hover:bg-slate-600 text-gray-300 hover:text-white'}`}
            >
              <NavIcon />
              <span>Main</span>
            </button>
            <button
              onClick={() => setCurrentPage(Page.Settings)}
              className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ease-in-out flex items-center space-x-2
                ${currentPage === Page.Settings 
                  ? 'bg-purple-600 hover:bg-purple-700 text-white shadow-lg' 
                  : 'bg-slate-700 hover:bg-slate-600 text-gray-300 hover:text-white'}`}
            >
              <SettingsIcon />
              <span>Settings</span>
            </button>
          </nav>
        </div>
        {!isApiKeySet && currentPage === Page.Main && (
             <div className="mt-4 p-3 bg-yellow-500 border border-yellow-600 text-yellow-900 rounded-md text-sm">
                <strong>Warning:</strong> Gemini API Key is not set. Please set it in the <strong>Settings</strong> menu for the AI to function.
             </div>
        )}
      </header>

      <main className="w-full max-w-5xl bg-slate-800 rounded-xl shadow-2xl p-6 md:p-8">
        {currentPage === Page.Settings && (
          <SettingsView currentConfig={appConfig} onSave={handleSaveConfig} />
        )}
        {currentPage === Page.Main && <MainView apiKey={appConfig.apiKey} promptsConfig={appConfig} />}
      </main>
      <footer className="w-full max-w-5xl mt-8 text-center text-sm text-gray-400">
        <p>&copy; {new Date().getFullYear()} AI Image Metadata Generator. Powered by Gemini.</p>
      </footer>
    </div>
  );
};

export default App;