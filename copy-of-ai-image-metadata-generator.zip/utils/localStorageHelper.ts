import type { PromptsConfig } from '../types';
import { APP_STORAGE_KEY, DEFAULT_PROMPTS } from '../constants';

export const savePromptsToStorage = (prompts: PromptsConfig): void => {
  try {
    localStorage.setItem(APP_STORAGE_KEY, JSON.stringify(prompts));
  } catch (error) {
    console.error("Error saving config to localStorage:", error);
  }
};

export const loadPromptsFromStorage = (): PromptsConfig => {
  try {
    const storedConfig = localStorage.getItem(APP_STORAGE_KEY);
    if (storedConfig) {
      const parsedConfig = JSON.parse(storedConfig);
      // Basic validation and ensure apiKey field exists, defaulting if not
      if (parsedConfig && 
          typeof parsedConfig.titlePrompt === 'string' &&
          typeof parsedConfig.keywordsPrompt === 'string' &&
          typeof parsedConfig.categoryPrompt === 'string') {
        return {
            ...DEFAULT_PROMPTS, // Start with defaults to ensure all keys are present
            ...parsedConfig, // Override with stored values
            apiKey: typeof parsedConfig.apiKey === 'string' ? parsedConfig.apiKey : DEFAULT_PROMPTS.apiKey, // Ensure apiKey is string
        };
      } else {
        // Invalid structure, remove it and return defaults
        localStorage.removeItem(APP_STORAGE_KEY);
        return DEFAULT_PROMPTS;
      }
    }
    return DEFAULT_PROMPTS; // Return defaults if nothing is stored
  } catch (error) {
    console.error("Error loading config from localStorage:", error);
    return DEFAULT_PROMPTS; // Fallback to defaults on error
  }
};