
import type { ImageMetadata, PromptsConfig } from '../types';

export const exportMetadataToCSV = (images: ImageMetadata[], prompts: PromptsConfig): void => {
  if (images.length === 0) {
    alert("No metadata to export.");
    return;
  }

  const header = [
    "Original Filename", 
    "Current Filename (or Generated Title as Filename)", 
    "Generated Title", 
    "Generated Keywords", 
    "Generated Category"
  ];
  
  const rows = images.map(image => [
    image.originalName,
    image.name, // This will be the generated title if renamed, else original/edited name
    image.title || "",
    image.keywords ? image.keywords.join(", ") : "",
    image.category || ""
  ]);

  // Add prompts used for this export session
  const promptInfo = [
    [""], // Empty line for spacing
    ["Prompts Used for this Export Session"],
    ["Title Prompt:", `"${prompts.titlePrompt.replace(/"/g, '""')}"`], // Escape quotes in prompt
    ["Keywords Prompt:", `"${prompts.keywordsPrompt.replace(/"/g, '""')}"`],
    ["Category Prompt:", `"${prompts.categoryPrompt.replace(/"/g, '""')}"`],
  ];

  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += header.join(",") + "\r\n";
  rows.forEach(rowArray => {
    const row = rowArray.map(field => `"${String(field).replace(/"/g, '""')}"`).join(","); // Escape double quotes
    csvContent += row + "\r\n";
  });

  promptInfo.forEach(rowArray => {
    const row = rowArray.map(field => `"${String(field).replace(/"/g, '""')}"`).join(",");
    csvContent += row + "\r\n";
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  link.setAttribute("download", `image_metadata_${timestamp}.csv`);
  document.body.appendChild(link); 
  link.click();
  document.body.removeChild(link);
};
