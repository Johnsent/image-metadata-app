export interface PromptsConfig {
  apiKey: string; // Added to store Gemini API Key
  titlePrompt: string;
  keywordsPrompt: string;
  categoryPrompt: string;
}

export interface ImageFile {
  id: string;
  file: File;
  previewUrl: string;
  name: string; // Original or user-modified name
}

export interface GeneratedMetadata {
  title: string;
  keywords: string[];
  category: string;
}

export interface ImageMetadata extends ImageFile, Partial<GeneratedMetadata> {
  status: 'pending' | 'processing' | 'completed' | 'error';
  errorMessage?: string;
  originalName: string; // To keep track of the very first name
}

export interface GeminiResponseJson {
  title: string;
  keywords: string[] | string; // Can be array or comma-separated string
  category: string;
}