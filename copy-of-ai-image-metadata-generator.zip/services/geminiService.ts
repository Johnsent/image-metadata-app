import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { PromptsConfig, GeminiResponseJson } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

const sanitizeJsonString = (jsonStr: string): string => {
  let S = jsonStr.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = S.match(fenceRegex);
  if (match && match[2]) {
    S = match[2].trim();
  }
  return S;
};

export const generateMetadataForImage = async (
  base64ImageData: string,
  fileName: string,
  promptsConfig: PromptsConfig, 
  apiKey: string 
): Promise<GeminiResponseJson> => {
  if (!apiKey) {
    throw new Error("Gemini API Key is not provided. Please set it in Settings.");
  }

  const ai = new GoogleGenAI({ apiKey });

  const { titlePrompt, keywordsPrompt, categoryPrompt } = promptsConfig;

  const combinedPrompt = `
    Analyze the provided image and its filename ('${fileName}') to generate metadata.
    Your response MUST be a single, valid JSON object with three keys: "title", "keywords", and "category".

    Instructions for each key:
    1. "title": ${titlePrompt.replace('{fileName}', fileName)}
    2. "keywords": ${keywordsPrompt.replace('{fileName}', fileName)} The value should be a JSON array of strings. If you can only generate a comma-separated string, that's acceptable as a fallback.
    3. "category": ${categoryPrompt.replace('{fileName}', fileName)} The value should be a single string.

    Example JSON output format:
    {
      "title": "A Cool Image Title",
      "keywords": ["keyword1", "keyword2", "keyword3"],
      "category": "Image Category"
    }
  `;
  
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg', 
      data: base64ImageData,
    },
  };

  const textPart = {
    text: combinedPrompt,
  };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: [{ parts: [imagePart, textPart] }],
      config: {
        responseMimeType: "application/json",
        temperature: 0.5,
      },
    });
    
    if (response.promptFeedback?.blockReason) {
      let blockMessage = `Request was blocked by the API: ${response.promptFeedback.blockReason}.`;
      if (response.promptFeedback.safetyRatings && response.promptFeedback.safetyRatings.length > 0) {
        blockMessage += ` Safety issues: ${response.promptFeedback.safetyRatings.filter(r => r.probability !== 'NEGLIGIBLE' && r.probability !== 'LOW').map(r => `${r.category} (${r.probability})`).join(', ')}`;
      }
      console.error("Gemini API request blocked:", blockMessage, response.promptFeedback);
      throw new Error(blockMessage);
    }

    const rawJsonText = response.text;
     if (!rawJsonText || rawJsonText.trim() === "") {
        console.error("Gemini API returned an empty response text. This could be due to an invalid API key or other configuration issues.");
        throw new Error("AI returned an empty response. This might be due to an issue with the API key or request configuration.");
    }
    const cleanedJsonText = sanitizeJsonString(rawJsonText);
    
    try {
      const parsedJson: any = JSON.parse(cleanedJsonText); 

      if (parsedJson && (typeof parsedJson.error === 'object' || typeof parsedJson.error === 'string')) {
        const errorMessageDetail = typeof parsedJson.error === 'object' ? JSON.stringify(parsedJson.error) : parsedJson.error;
        console.error("Gemini API returned an error object within JSON response:", errorMessageDetail);
        if (typeof errorMessageDetail === 'string' && (errorMessageDetail.toLowerCase().includes('api key not valid') || errorMessageDetail.toLowerCase().includes('invalid api key'))) {
             throw new Error("Gemini API key is not valid. Please check it in Settings.");
        }
        throw new Error(`AI returned an error in the response: ${errorMessageDetail.substring(0, 150)}${errorMessageDetail.length > 150 ? '...' : ''}`);
      }
      
      if (typeof parsedJson.title !== 'string' || 
          (!Array.isArray(parsedJson.keywords) && typeof parsedJson.keywords !== 'string') || 
          typeof parsedJson.category !== 'string') {
        console.error("Parsed JSON does not match expected metadata structure:", parsedJson);
        throw new Error("AI response JSON structure is invalid. Received: " + JSON.stringify(parsedJson).substring(0,150) + "...");
      }
      
      let finalKeywords: string[];
      if (typeof parsedJson.keywords === 'string') {
        finalKeywords = parsedJson.keywords.split(',').map((k: string) => k.trim()).filter((k: string) => k.length > 0);
      } else {
        finalKeywords = parsedJson.keywords.map(String); 
      }

      return {
        title: parsedJson.title,
        keywords: finalKeywords,
        category: parsedJson.category
      } as GeminiResponseJson;

    } catch (parseError: any) {
      console.error("Failed to parse JSON response from AI:", parseError.message);
      console.error("Original AI response text (cleaned):", cleanedJsonText.substring(0, 500));
      const combinedTextForCheck = (parseError.message + cleanedJsonText).toLowerCase();
      if (combinedTextForCheck.includes('api key not valid') || combinedTextForCheck.includes('api_key_invalid') || combinedTextForCheck.includes('invalid api key')) {
         throw new Error("Gemini API key is not valid. Please check it in Settings. (Detected during response parsing)");
      }
      throw new Error(`Failed to parse AI response. Raw text (partial): ${cleanedJsonText.substring(0,100)}...`);
    }

  } catch (error: any) {
    console.error("Error calling Gemini API:", error.message, error);
    let errorMessage = error.message || "An unknown error occurred with the Gemini API.";
    const lowerErrorMessage = errorMessage.toLowerCase();

    if (lowerErrorMessage.includes('api key not valid') ||
        lowerErrorMessage.includes('api_key_invalid') ||
        lowerErrorMessage.includes('invalid api key') ||
        (lowerErrorMessage.includes('permission denied') && (lowerErrorMessage.includes('api key') || lowerErrorMessage.includes('credential'))) ||
        lowerErrorMessage.includes('authentication failed') ||
        lowerErrorMessage.includes('unauthenticated') ||
        lowerErrorMessage.includes('401') || // HTTP 401 Unauthorized
        lowerErrorMessage.includes('403')    // HTTP 403 Forbidden
    ) {
        throw new Error("Gemini API key is not valid, lacks permissions, or is unauthenticated. Please check it in Settings.");
    }
    
    if (lowerErrorMessage.includes('quota')) {
        throw new Error("API quota exceeded. Please check your Gemini account or try again later.");
    }
    if (lowerErrorMessage.includes('request was blocked') || lowerErrorMessage.includes('safety issues')) {
        throw new Error(errorMessage); 
    }
     if (lowerErrorMessage.includes('ai returned an empty response') || lowerErrorMessage.includes('failed to parse ai response')) {
        throw error; 
    }
    throw new Error(errorMessage);
  }
};