
import React, { useState, useCallback } from 'react';
import type { PromptsConfig, ImageMetadata } from '../types';
import { MAX_IMAGE_UPLOADS, ACCEPTED_IMAGE_TYPES, MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_MB } from '../constants';
import { generateMetadataForImage } from '../services/geminiService';
import { ImagePreviewCard } from './ImagePreviewCard';
import { LoadingSpinner } from './LoadingSpinner';
import { exportMetadataToCSV } from '../utils/csvHelper';
import { UploadIcon, GenerateIcon, DownloadIcon, TrashIcon } from './icons';

interface MainViewProps {
  apiKey: string; // Added apiKey prop
  promptsConfig: PromptsConfig;
}

export const MainView: React.FC<MainViewProps> = ({ apiKey, promptsConfig }) => {
  const [images, setImages] = useState<ImageMetadata[]>([]);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<boolean>(false);

  const clearFileInput = () => {
    const fileInput = document.getElementById('fileUpload') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };
  
  const processFiles = async (incomingFiles: FileList | File[]) => {
    setError(null); 
    const filesArray = Array.from(incomingFiles);

    const currentImageCount = images.length;
    const remainingSlots = MAX_IMAGE_UPLOADS - currentImageCount;

    if (remainingSlots <= 0) {
      setError(`Cannot upload more images. Maximum ${MAX_IMAGE_UPLOADS} images allowed.`);
      clearFileInput();
      return;
    }

    const filesToConsider = filesArray.slice(0, remainingSlots);
    const filesToActuallyProcess: File[] = [];
    
    const errorMessages: string[] = [];
    const oversizedFiles: string[] = [];
    const invalidTypeFiles: string[] = [];

    for (const file of filesToConsider) {
      if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
        invalidTypeFiles.push(file.name);
        continue;
      }
      if (file.size > MAX_FILE_SIZE_BYTES) {
        oversizedFiles.push(file.name);
        continue;
      }
      filesToActuallyProcess.push(file);
    }

    if (oversizedFiles.length > 0) {
      errorMessages.push(`Files too large: ${oversizedFiles.join(', ')}. Max size is ${MAX_FILE_SIZE_MB}MB.`);
    }
    if (invalidTypeFiles.length > 0) {
      errorMessages.push(`Invalid file types: ${invalidTypeFiles.join(', ')}. Only JPG, PNG, WEBP accepted.`);
    }
    if (filesArray.length > filesToConsider.length && filesToActuallyProcess.length > 0) {
       errorMessages.push(`Some files were not uploaded as the maximum of ${MAX_IMAGE_UPLOADS} images would be exceeded.`);
    } else if (filesArray.length > filesToConsider.length && filesToActuallyProcess.length === 0 && remainingSlots > 0) {
      if (invalidTypeFiles.length === 0 && oversizedFiles.length === 0) { 
         errorMessages.push(`Could not add all files. Max ${MAX_IMAGE_UPLOADS} images. ${invalidTypeFiles.length + oversizedFiles.length > 0 ? 'Also, some files had type/size issues.' : ''}`);
      }
    }

    if (errorMessages.length > 0) {
      setError(errorMessages.join(' '));
    }

    if (filesToActuallyProcess.length === 0) {
      clearFileInput();
      return;
    }
    
    const imagePromises = filesToActuallyProcess.map(file => {
      return new Promise<ImageMetadata>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          resolve({
            id: crypto.randomUUID(),
            file,
            previewUrl: reader.result as string,
            name: file.name,
            originalName: file.name,
            status: 'pending',
          });
        };
        reader.onerror = (errorEvent) => reject(new Error(`Error reading file ${file.name}: ${errorEvent}`));
        reader.readAsDataURL(file);
      });
    });

    try {
      const newImageObjects = await Promise.all(imagePromises);
      setImages(prev => [...prev, ...newImageObjects].slice(0, MAX_IMAGE_UPLOADS));
    } catch (readError: any) {
      console.error("Error reading files:", readError);
      setError(readError.message || "An error occurred while reading files. Please try again.");
    }
    
    clearFileInput();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      processFiles(files);
    }
  };
  
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragOver(false);
    const files = event.dataTransfer.files;
    if (files) {
      processFiles(files);
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragOver(true);
  };

  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragOver(false);
  };

  const handleGenerateMetadata = async () => {
    if (!apiKey) {
      setError("API Key is not set. Please configure it in Settings.");
      return;
    }
    if (images.filter(img => img.status === 'pending' || img.status === 'error').length === 0) {
      alert("All images have already been processed or there are no images to process.");
      return;
    }
    setIsGenerating(true);
    setError(null);

    const imagesToProcess = images.filter(img => img.status === 'pending' || img.status === 'error');

    for (const image of imagesToProcess) {
      setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'processing', errorMessage: undefined } : img));
      try {
        const base64Data = image.previewUrl.split(',')[1];
        // Pass apiKey to the service
        const result = await generateMetadataForImage(base64Data, image.name, promptsConfig, apiKey); 
        
        let parsedKeywords: string[] = [];
        if (typeof result.keywords === 'string') {
            try {
                const tempKeywords = JSON.parse(result.keywords);
                if (Array.isArray(tempKeywords)) {
                    parsedKeywords = tempKeywords.map(String);
                } else {
                     parsedKeywords = result.keywords.split(',').map(k => k.trim()).filter(k => k);
                }
            } catch (e) {
                parsedKeywords = result.keywords.split(',').map(k => k.trim()).filter(k => k);
            }
        } else if (Array.isArray(result.keywords)) {
            parsedKeywords = result.keywords.map(String);
        }

        setImages(prev => prev.map(img => img.id === image.id ? {
          ...img,
          title: result.title,
          keywords: parsedKeywords,
          category: result.category,
          status: 'completed'
        } : img));
      } catch (err: any) {
        console.error(`Error generating metadata for ${image.name}:`, err);
        setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'error', errorMessage: err.message || 'Failed to generate metadata' } : img));
      }
    }
    setIsGenerating(false);
  };

  const handleRenameFile = useCallback((id: string, newName: string) => {
    setImages(prev => prev.map(img => img.id === id ? { ...img, name: newName } : img));
  }, []);

  const handleRemoveImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  };
  
  const handleClearAll = () => {
    setImages([]);
    setError(null);
  };

  const allProcessedOrNoPending = images.length === 0 || images.every(img => img.status === 'completed' || img.status === 'error');
  const anyCompleted = images.some(img => img.status === 'completed');
  const noPendingImages = images.every(img => img.status !== 'pending' && img.status !== 'processing');

  return (
    <div className="space-y-8">
      {error && <div className="p-4 bg-red-700 border border-red-900 text-white rounded-md shadow-lg whitespace-pre-line">{error}</div>}
      
      <div 
        className={`p-8 border-2 border-dashed rounded-lg text-center transition-colors duration-300
                    ${dragOver ? 'border-sky-500 bg-slate-700' : 'border-slate-600 hover:border-sky-600 bg-slate-700/50'}
                    ${images.length >= MAX_IMAGE_UPLOADS ? 'opacity-70 cursor-not-allowed' : ''}
                    `}
        onDrop={images.length >= MAX_IMAGE_UPLOADS ? undefined : handleDrop}
        onDragOver={images.length >= MAX_IMAGE_UPLOADS ? undefined : handleDragOver}
        onDragLeave={images.length >= MAX_IMAGE_UPLOADS ? undefined : handleDragLeave}
        aria-disabled={images.length >= MAX_IMAGE_UPLOADS}
      >
        <label htmlFor="fileUpload" className={`cursor-pointer w-full flex flex-col items-center ${images.length >= MAX_IMAGE_UPLOADS ? 'pointer-events-none' : ''}`}>
          <UploadIcon className="w-12 h-12 mb-3 text-sky-400" />
          <p className="text-xl font-semibold text-gray-200 mb-1">Drag &amp; drop images here, or click to select</p>
          <p className="text-sm text-gray-400">Max {MAX_IMAGE_UPLOADS} images (JPG, PNG, WEBP), up to {MAX_FILE_SIZE_MB}MB each.</p>
          <input
            id="fileUpload"
            type="file"
            multiple
            accept={ACCEPTED_IMAGE_TYPES.join(',')}
            onChange={handleFileChange}
            className="hidden"
            disabled={isGenerating || images.length >= MAX_IMAGE_UPLOADS}
          />
        </label>
        {images.length >= MAX_IMAGE_UPLOADS && <p className="mt-2 text-sm text-yellow-400">Maximum number of images reached ({MAX_IMAGE_UPLOADS}).</p>}
      </div>

      {images.length > 0 && (
        <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <button
            onClick={handleGenerateMetadata}
            disabled={isGenerating || allProcessedOrNoPending || !apiKey}
            className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 disabled:transform-none"
            title={!apiKey ? "API Key not set. Please configure it in Settings." : (allProcessedOrNoPending ? "All images processed or no pending images" : "Generate metadata for pending images")}
          >
            {isGenerating ? <LoadingSpinner size="sm" /> : <GenerateIcon />}
            <span>{isGenerating ? 'Generating...' : (noPendingImages && images.length > 0 ? 'Metadata Generated' : 'Generate Metadata')}</span>
          </button>
          <div className="flex space-x-3 w-full sm:w-auto">
            <button
              onClick={() => exportMetadataToCSV(images.filter(img => img.status === 'completed'), promptsConfig)}
              disabled={!anyCompleted || isGenerating}
              className="w-1/2 sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 disabled:transform-none"
            >
              <DownloadIcon />
              <span>Export CSV</span>
            </button>
             <button
              onClick={handleClearAll}
              disabled={isGenerating}
              className="w-1/2 sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 disabled:transform-none"
            >
              <TrashIcon />
              <span>Clear All</span>
            </button>
          </div>
        </div>
      )}

      {images.length > 0 && (
        <div className="mt-8 space-y-6">
          <h3 className="text-2xl font-semibold text-sky-300">Uploaded Images & Metadata ({images.length}/{MAX_IMAGE_UPLOADS})</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((image) => (
              <ImagePreviewCard 
                key={image.id} 
                image={image} 
                onRename={handleRenameFile}
                onRemove={handleRemoveImage} 
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};