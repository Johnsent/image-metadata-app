
import React, { useState, useEffect } from 'react';
import type { ImageMetadata } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { CheckCircleIcon, ExclamationTriangleIcon, EditIcon, TrashIcon } from './icons'; // Changed PencilIcon to EditIcon


interface ImagePreviewCardProps {
  image: ImageMetadata;
  onRename: (id: string, newName: string) => void;
  onRemove: (id: string) => void;
}

export const ImagePreviewCard: React.FC<ImagePreviewCardProps> = ({ image, onRename, onRemove }) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [editableName, setEditableName] = useState(image.name);

  useEffect(() => {
    setEditableName(image.name); // Sync with parent changes if title replaces name
  }, [image.name]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditableName(e.target.value);
  };

  const handleNameSave = () => {
    if (editableName.trim() === "") {
      alert("Filename cannot be empty.");
      setEditableName(image.name); // Reset to original if empty
      setIsEditingName(false);
      return;
    }
    onRename(image.id, editableName.trim());
    setIsEditingName(false);
  };

  const handleNameEditKeydown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleNameSave();
    } else if (e.key === 'Escape') {
      setEditableName(image.name);
      setIsEditingName(false);
    }
  };

  const handleRenameWithTitle = () => {
    if (image.title) {
      // Basic sanitization for filename
      const newName = image.title.replace(/[^a-zA-Z0-9_.\s-]/g, '').replace(/\s+/g, '_');
      const extension = image.originalName.includes('.') ? image.originalName.substring(image.originalName.lastIndexOf('.')) : '.jpg'; // Keep original or default extension
      onRename(image.id, `${newName}${extension}`);
    }
  };

  const renderStatusIcon = () => {
    switch (image.status) {
      case 'processing':
        return <LoadingSpinner size="sm" />;
      case 'completed':
        return <CheckCircleIcon className="w-5 h-5 text-green-400" />;
      case 'error':
        return <ExclamationTriangleIcon className="w-5 h-5 text-red-400" />;
      default:
        return null;
    }
  };
  
  const cardBorderColor = () => {
    switch (image.status) {
      case 'processing': return 'border-blue-500';
      case 'completed': return 'border-green-500';
      case 'error': return 'border-red-500';
      default: return 'border-slate-600';
    }
  };

  return (
    <div className={`bg-slate-700 rounded-xl shadow-lg overflow-hidden border-2 ${cardBorderColor()} flex flex-col transition-all duration-300`}>
      <div className="relative h-48 w-full">
        <img src={image.previewUrl} alt={image.name} className="w-full h-full object-cover" />
        <button 
          onClick={() => onRemove(image.id)} 
          className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white p-1.5 rounded-full shadow-md transition-colors"
          aria-label="Remove image"
        >
          <TrashIcon className="w-4 h-4" />
        </button>
      </div>
      
      <div className="p-4 flex-grow flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-2">
            {isEditingName ? (
              <input
                type="text"
                value={editableName}
                onChange={handleNameChange}
                onBlur={handleNameSave}
                onKeyDown={handleNameEditKeydown}
                className="text-sm font-semibold bg-slate-600 text-gray-100 px-2 py-1 rounded w-full focus:ring-1 focus:ring-sky-500 outline-none"
                autoFocus
              />
            ) : (
              <h3 className="text-sm font-semibold text-sky-300 truncate pr-2" title={image.name}>
                {image.name}
              </h3>
            )}
            {!isEditingName && (
              <button onClick={() => setIsEditingName(true)} className="text-gray-400 hover:text-sky-400 transition-colors p-1">
                <EditIcon className="w-4 h-4" /> {/* Changed PencilIcon to EditIcon */}
              </button>
            )}
          </div>
          
          <div className="flex items-center space-x-2 mb-3">
            <span className="text-xs text-gray-400">Status:</span>
            {renderStatusIcon()}
            <span className={`text-xs font-medium ${
              image.status === 'completed' ? 'text-green-400' :
              image.status === 'error' ? 'text-red-400' :
              image.status === 'processing' ? 'text-blue-400' : 'text-gray-400'
            }`}>
              {image.status === 'error' ? 'Error' : image.status.charAt(0).toUpperCase() + image.status.slice(1)}
            </span>
          </div>

          {image.status === 'error' && image.errorMessage && (
            <p className="text-xs text-red-400 bg-red-900/30 p-2 rounded mb-2">{image.errorMessage}</p>
          )}

          {image.status === 'completed' && (
            <div className="space-y-2 text-xs">
              <div>
                <strong className="text-gray-300">Title:</strong>
                <p className="text-gray-400 break-words">{image.title || 'N/A'}</p>
              </div>
              <div>
                <strong className="text-gray-300">Keywords:</strong>
                <div className="flex flex-wrap gap-1 mt-1">
                  {image.keywords && image.keywords.length > 0 ? image.keywords.map((kw, i) => (
                    <span key={i} className="bg-slate-600 text-sky-300 px-2 py-0.5 rounded-full text-xs">{kw}</span>
                  )) : <span className="text-gray-500">N/A</span>}
                </div>
              </div>
              <div>
                <strong className="text-gray-300">Category:</strong>
                <p className="text-gray-400">{image.category || 'N/A'}</p>
              </div>
            </div>
          )}
        </div>
        
        {image.status === 'completed' && image.title && (
          <button
            onClick={handleRenameWithTitle}
            className="mt-4 w-full text-xs bg-sky-600 hover:bg-sky-700 text-white px-3 py-1.5 rounded-md transition-colors text-center"
          >
            Rename file with generated title
          </button>
        )}
      </div>
    </div>
  );
};
