
import React, { useState, useEffect } from 'react';
import type { PromptsConfig } from '../types';
import { SaveIcon, KeyIcon } from './icons'; // Assuming KeyIcon exists or will be added

// Placeholder for KeyIcon if not already defined in icons.tsx
const KeyIconPlaceholder: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 ${props.className || ''}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
  </svg>
);


interface SettingsViewProps {
  currentConfig: PromptsConfig;
  onSave: (config: PromptsConfig) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ currentConfig, onSave }) => {
  const [config, setConfig] = useState<PromptsConfig>(currentConfig);
  const [showApiKey, setShowApiKey] = useState(false);

  useEffect(() => {
    setConfig(currentConfig);
  }, [currentConfig]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setConfig(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(config);
  };

  const inputClass = "w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors text-gray-200 placeholder-gray-400";
  const labelClass = "block mb-2 text-sm font-medium text-sky-300";

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-semibold mb-1 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">Configuration</h2>
        <p className="text-sm text-gray-400 mb-6">
          Set your Gemini API Key and customize AI prompts.
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="apiKey" className={labelClass}>Gemini API Key:</label>
          <div className="relative">
            <input
              type={showApiKey ? "text" : "password"}
              id="apiKey"
              name="apiKey"
              value={config.apiKey}
              onChange={handleChange}
              className={`${inputClass} pr-10`}
              placeholder="Enter your Gemini API Key"
              aria-describedby="apiKeyHelp"
            />
            <button
              type="button"
              onClick={() => setShowApiKey(!showApiKey)}
              className="absolute inset-y-0 right-0 px-3 flex items-center text-sm text-gray-400 hover:text-sky-300"
              aria-label={showApiKey ? "Hide API Key" : "Show API Key"}
            >
              {showApiKey ? (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              )}
            </button>
          </div>
          <p id="apiKeyHelp" className="mt-1 text-xs text-yellow-400 bg-yellow-900/30 p-2 rounded">
            <strong>Security Warning:</strong> Storing your API Key in the browser (localStorage) can be insecure if this page is vulnerable to XSS attacks. For production, manage API keys on a secure backend. This method is for ease of use in this client-side demo.
          </p>
        </div>
        
        <hr className="border-slate-600 my-8" />
        <h3 className="text-2xl font-semibold mb-1 text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500">AI Prompts</h3>
        <p className="text-sm text-gray-400 mb-6">
          These prompts guide the AI in generating metadata. Use <code>{'{fileName}'}</code> placeholder to include the image's filename in the prompt.
        </p>

        <div>
          <label htmlFor="titlePrompt" className={labelClass}>Title Generation Prompt:</label>
          <textarea
            id="titlePrompt"
            name="titlePrompt"
            value={config.titlePrompt}
            onChange={handleChange}
            rows={3}
            className={`${inputClass} resize-none`}
            placeholder="e.g., Generate a catchy title for an image based on its content and filename '{fileName}'."
            aria-describedby="titlePromptHelp"
          />
          <p id="titlePromptHelp" className="mt-1 text-xs text-gray-500">Enter the prompt for generating image titles.</p>
        </div>
        <div>
          <label htmlFor="keywordsPrompt" className={labelClass}>Keywords Generation Prompt:</label>
          <textarea
            id="keywordsPrompt"
            name="keywordsPrompt"
            value={config.keywordsPrompt}
            onChange={handleChange}
            rows={3}
            className={`${inputClass} resize-none`}
            placeholder="e.g., Extract 5 relevant keywords for the image '{fileName}'. Return as a JSON array."
            aria-describedby="keywordsPromptHelp"
          />
          <p id="keywordsPromptHelp" className="mt-1 text-xs text-gray-500">Enter the prompt for generating image keywords. Expects a JSON array of strings from the AI.</p>
        </div>
        <div>
          <label htmlFor="categoryPrompt" className={labelClass}>Category Generation Prompt:</label>
          <textarea
            id="categoryPrompt"
            name="categoryPrompt"
            value={config.categoryPrompt}
            onChange={handleChange}
            rows={3}
            className={`${inputClass} resize-none`}
            placeholder="e.g., Assign a suitable category to the image '{fileName}'."
            aria-describedby="categoryPromptHelp"
          />
          <p id="categoryPromptHelp" className="mt-1 text-xs text-gray-500">Enter the prompt for generating image categories.</p>
        </div>
        <div className="flex justify-end">
          <button 
            type="submit" 
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105"
            aria-label="Save configuration"
          >
            <SaveIcon />
            <span>Save Configuration</span>
          </button>
        </div>
      </form>
    </div>
  );
};