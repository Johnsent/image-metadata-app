import type { PromptsConfig } from './types';

export const APP_STORAGE_KEY = 'aiImageMetadataAppConfig';

export const DEFAULT_PROMPTS: PromptsConfig = {
  apiKey: '', // Default empty API Key
  titlePrompt: "Generate a concise, descriptive title for an image. The image might be related to its filename: '{fileName}'. Focus on the main subject and mood.",
  keywordsPrompt: "List 5-7 relevant keywords for an image. The image might be related to its filename: '{fileName}'. Keywords should be suitable for search and categorization. Return as a JSON array of strings.",
  categoryPrompt: "Suggest a single, broad category for an image (e.g., Nature, Technology, Portrait, Abstract). The image might be related to its filename: '{fileName}'.",
};

export const MAX_IMAGE_UPLOADS = 10;
export const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const MAX_FILE_SIZE_MB = 5; // 5MB per image
export const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';